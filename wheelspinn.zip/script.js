
function startGame() {

    const name = document.getElementById("playerName").value.trim();

    if(name === ""){

        alert("Please enter your full name.");

        return;

    }

    playerName = name;

    document.getElementById("namePopup").classList.add("hidden");

}

function closePopup(){

    document.getElementById("resultPopup").classList.add("hidden");

}