
const canvas = document.getElementById("wheel");
const ctx = canvas.getContext("2d");

const prizes = [
  "10%",
  "20%",
  "30%",
  "40%",
  "50%",
  "75%",
  "100%",
  "JACKPOT",
  "TRY AGAIN",
  "TRY AGAIN"
];

const colors = [
  "#FFD700",
  "#FF6B6B",
  "#4ECDC4",
  "#45B7D1",
  "#96CEB4",
  "#FF9F1C",
  "#9B5DE5",
  "#2EC4B6",
  "#B0B0B0",
  "#777777"
];

const slices = prizes.length;
const arc = (2 * Math.PI) / slices;

let rotation = 0;
let spinning = false;
let playerName = "";

function drawWheel() {

    ctx.clearRect(0,0,500,500);

    for(let i=0;i<slices;i++){

        let angle = i * arc + rotation;

        ctx.beginPath();
        ctx.moveTo(250,250);
        ctx.arc(250,250,230,angle,angle+arc);
        ctx.fillStyle = colors[i];
        ctx.fill();

        ctx.save();

        ctx.translate(250,250);

        ctx.rotate(angle + arc/2);

        ctx.fillStyle="white";
        ctx.font="bold 20px Arial";
        ctx.textAlign="right";

        ctx.fillText(prizes[i],200,8);

        ctx.restore();

    }

    ctx.beginPath();
    ctx.arc(250,250,45,0,Math.PI*2);
    ctx.fillStyle="#FFD700";
    ctx.fill();

    ctx.fillStyle="black";
    ctx.font="bold 18px Arial";
    ctx.textAlign="center";
    ctx.fillText("SPIN",250,258);

}

drawWheel();


function spinWheel() {

    if (spinning) return;

    spinning = true;

    // Random winning slice
    const winningIndex = Math.floor(Math.random() * prizes.length);

    // Calculate target angle
    const targetAngle =
        (Math.PI * 2 * 8) +
        ((Math.PI * 2) - (winningIndex * arc) - (arc / 2));

    const start = rotation;
    const duration = 5000;
    const startTime = performance.now();

    function animate(now) {

        let progress = (now - startTime) / duration;

        if (progress > 1) progress = 1;

        // Ease-out animation
        const ease = 1 - Math.pow(1 - progress, 3);

        rotation = start + (targetAngle - start) * ease;

        drawWheel();

        if (progress < 1) {

            requestAnimationFrame(animate);

        } else {

            spinning = false;

            showPrize(prizes[winningIndex]);

        }

    }

    requestAnimationFrame(animate);

}

function showPrize(prize) {

    document.getElementById("resultPopup").classList.remove("hidden");

    document.getElementById("resultTitle").innerHTML =
        prize === "TRY AGAIN"
            ? "😔 Better Luck Next Time!"
            : "🎉 Congratulations!";

    document.getElementById("resultText").innerHTML =
        prize === "TRY AGAIN"
            ? `${playerName}, try again!`
            : `${playerName}, you won <b>${prize}</b> bonus!<br><br>Take a screenshot and send it to David Gaming House to claim.`;

}

document.getElementById("spinBtn").addEventListener("click", spinWheel);